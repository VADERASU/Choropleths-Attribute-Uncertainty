const LB={loadingBar:$('<div class="loadingBar"></div>')}

LB.init=function(state){
    	LB.loadingBar.width(0);
    	$('body').append(LB.loadingBar);
    }
LB.progressLoadingBar=function(progress){
		// console.log('progressLoadingBar');
		var width =  LB.loadingBar.width();
		var delay = 0;

		if(progress){
			if(progress > 0.1){
				width += (progress - 0.1) * window.innerWidth;
				delay = 250;
			}
		}
		else if(width < window.innerWidth - 0.01 * window.innerWidth){
			width += 0.01 * window.innerWidth;
		}
		else{
			return;
		}
		LB.loadingBar.animate(
	        { width: width },
	        delay
	    );
	}
LB.hideLoading=function (){
		LB.hideLoadingBar();
		$('#loadingScreen').hide();
}
LB.hideLoadingBar = function(delay) {
	    let fadeOut = 100;

	    if(delay)
	        fadeOut = delay;

	    LB.loadingBar.animate(
	        { width: window.innerWidth },
	        500,
	        function() { LB.loadingBar.fadeOut(delay); }
	    );
	}
LB.showLoading =function (showScreen){
		LB.showLoadingBar();
		if(showScreen){
			$('#loadingScreen').show();
			$('#fountainTextG').css({
				left: ($(window).width() - $('#fountainTextG').outerWidth())/2,
				top: ($(window).height() - $('#fountainTextG').outerHeight())/2
			});
		}
	}
LB.showLoadingBar=function(){
	    LB.loadingBar.fadeIn(100);
	    LB.loadingBar.width(0.1 * window.innerWidth);
	    LB.progressLoadingBar(0.05);
    }
module.exports = LB;
