const state = require("./state.js");
const map = require("./MapManager.js");
const MA= require("./Math/mathmatic.js");

const filemanager = {
		init:function(state){
			$('#openfilebutton1').click(function() {
			  	filemanager.fileOpen(null,state)
			});
			// $('#openfilebutton2').click(function() {
			//   filemanager.fileOpen('./CommAreasNew.zip',state)
			// });
			// cb_2016_us_ua10_500k
			$('#openfilebutton2').click(function() {
			  filemanager.fileOpen('./cb_2016_18_bg_500k.zip',state)
			});
			$('#openfilebutton3').click(function() {
			  filemanager.fileOpen('./okyomet262a.zip',state)
			});
			$('#openfilebutton4').click(function() {
			  filemanager.fileOpen('./AfricaSocioEconimic.zip',state)
			});
		},
		fileOpen : function(file,state){
			console.log("---------------Open start---------------")
			if(!file)
		    	$('#fileInput').click();
			else{
				// If map layer already exists remove the layer
				// and clear the scatter plot
				if(state.map.layer){
					state.map.obj.removeLayer(state.map.layer);
					state.map.layer = false;

					$('#scat-svg').remove();
					state.scat.drawn = false;
				}
				
				map.clearComparisonMaps();
				state.selectedList = [];
				
				if(file.indexOf('AfricaSocioEconimic') > -1){
					state.map.obj.setView([4.39, 19.69]);
					state.map.obj.setZoom(3);
				}
				else if(file.indexOf('tokyomet262a') > -1){
					state.map.obj.setView([35.7198,139.7653]);
					state.map.obj.setZoom(9);
				}
				else{
					state.map.obj.setView([40.4, -86.9]);
					state.map.obj.setZoom(10);	
				}
				
				var center = state.map.obj.getCenter();
				state.maxMap.setView(center);
				state.map.obj.setZoom(10);	
				
				filemanager.readShapeFile(file,state)
			}
		},
		
		readShapeFile:function (file,state){
			shp(file).then(function(geojson){
				let newfeature= new Array()
				for(let ob of geojson.features){
					if(MA.IsInArea(ob.geometry.bbox,[-87.086,40.233,-86.695,40.60])){
						ob.properties.AREA_NUMBE=newfeature.length
						ob.properties.burglary=0;
						ob.properties.disturbances=0;
						ob.properties.domestic_disturbances=0;
						ob.properties.drunkness=0;
						ob.properties.noise=0;
						ob.properties.robbery=0;
						ob.properties.battery=0;
						ob.properties.theft=0;
						ob.properties.sum=0;
						ob.properties.crimelist=[];
						newfeature.push(ob)
					}
				}
				geojson.features=newfeature

				let crimedata
				$.ajax({
				        type: "GET",
				        url: "purdue_events.csv",
				        dataType: "text",
				        async:false, 
				        success: function(data) {
				        	crimedata=data.split("\n")
				        	crimedata=crimedata.splice(1)
				        	for(let i=0;i<crimedata.length;i++){
				        		let crime=crimedata[i]
				        		crimedata[i]={id:crime.split(",")[0],latitude:crime.split(",")[1],longitude:crime.split(",")[2],
				        					category:crime.split(",")[3],incident_date:crime.split(",")[4]}
				        	}
					    }
				 });
				// console.log(crimedata)

				for(let crime of crimedata){
					// console.log(crime)
					if(crime.longitude==undefined||crime.latitude==undefined){
						continue
					}
					// L.marker([crime.latitude,crime.longitude]).addTo(state.map.obj);

					for(let area of geojson.features){
						if(MA.IsPointInArea([crime.longitude,crime.latitude],area.geometry.bbox)){
							let areacoor=[]
							for (let thiscoor of area.geometry.coordinates[0]){
								areacoor.push({x:thiscoor[0],y:thiscoor[1]})
							}
							// console.log({x:crime.longitude ,y:crime.latitude}, areacoor)
							if(MA.checkPP({x:crime.longitude ,y:crime.latitude}, areacoor)){
								// console.log("find")
									area.properties.sum++
									area.properties.crimelist.push(crime)
								switch(crime.category){
									case "BURGLARY":
										area.properties.burglary++
										break;
									case "DISTURBANCES":
										area.properties.disturbances++
										break;
									case "DOMESTIC DISTURBANCE":
										console.log("sssss")
										area.properties.domestic_disturbances++
										break;
									case "DRUNKNESS":
										area.properties.drunkness++
										break;
									case "NOISE":
										area.properties.noise++
										break;
									case "ROBBERY":
										area.properties.robbery++
										break;
									case "BATTERY":
										area.properties.battery++
										break;
									case "THEFT":
										area.properties.theft++
										break;
									default://DOMESTIC DISTURBANCE
										area.properties.domestic_disturbances++
								}
							}
						}
					}
				}

				let NoeEmptyGF=[]
				for(let area of geojson.features){
					if(area.properties.sum!=0){
						NoeEmptyGF.push(area)
					}
				}
				geojson.features = NoeEmptyGF
				state.map.geojson = geojson;

				// Empty the feature list and recreate it from geojson properties
				$('#feature-list').selectpicker('destroy');
					let attrinput = d3.select("#feature-list")
					attrinput.selectAll("option").remove()
				for(var prop in geojson.features[0].properties){
					if(typeof(geojson.features[0].properties[prop]) == "number"){
						attrinput.append("option")
							.attr("value",prop)
							.text(prop)
					}
				}
				$('#feature-list').selectpicker('show');

				$('#map-controls').show();
				

				var polygons = new Array(geojson.features.length);

				for(var i = 0; i < polygons.length; i++)
					polygons[i] = geojson.features[i].geometry.bbox;

				AdjList(polygons,state);

				//distance
				polygonAdjList()

				console.log("data : ",state.map.geojson)
				console.log("---------------Open end---------------")
			});
		}
}


function polygonAdjList(){
	let data = state.map.geojson.features
	let result=[];
	for(let i = 0; i < data.length ; i++){
		let rowresult=[];
		for(let j = 0; j < data.length ; j++){
			rowresult.push(ispolygonAdj(data[i].geometry.coordinates[0], data[j].geometry.coordinates[0]))
		}
		result.push(rowresult);
	}
	state.data.PolygonAdjList = result
}


function ispolygonAdj(polygon1,polygon2){
	let mindis=100
	for( let point1 of polygon1){
		for (let point2 of polygon2){
			let dis = Math.sqrt(  (point1[0]-point2[0])*(point1[0]-point2[0])+
				(point1[1]-point2[1])*(point1[1]-point2[1]) )
			if(mindis>dis)
				mindis = dis
		}
	}
	if (mindis==0)
	return true

	return false
}

function AdjList(vectors,state){
	state.data.adjList = false;
	let result=[];
	for(let i = 0; i < vectors.length ; i++){
		let rowresult=[];
		for(let j = 0; j < vectors.length ; j++){
			if( i != j && Intersect(vectors[i], vectors[j])){
				rowresult.push(j)
			}
		}
		result.push(rowresult);
	}
	state.data.adjList = result
}
function Intersect(bb1,bb2){
			return ! ( bb2[0] > bb1[2] 
						|| bb2[2] < bb1[0]
						|| bb2[1] > bb1[3]
						|| bb2[3] < bb1[1] ); 
		}

module.exports=filemanager