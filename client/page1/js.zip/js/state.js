const state = {
	listresult:[],
	scat: {
		drawn: false,
		obj: null
	},
	map: {
		refreshed: false,
		layer: false
	},
	layers:{},
	activeView: '#og-map',
	/* color: d3.scale.category10(), */
	color: function(value){
			let colors = ['#377eb8','#4daf4a','#984ea3','#ff7f00','#ffff33','#a65628','#f781bf','#999999'];
			return colors[value];
		},
	data: {},
	useClustering: true,
	test: false,
	selectedFeatures: [],
	loadingText: ["", "L", "o", "a", "d", "i", "n", "g", ".", "."]
};
module.exports = state;

