const state = require("./state.js");
const Kmeans= require("./Kmeans/Kmeans.js")

const ClusterAl = {
	Cluster : function(k, vectors, type) {
		switch (type) {
			case "kmeans":
				let clusterdata = ClusterAl.Kmeans(vectors, k);
				updateFeaturesWithClusters(clusterdata.clustersnormal);
				state.data.kmeans = clusterdata.clustersnormal;
				state.data.stacenters = clusterdata.centroids;
				break;
		}

		let membership = [];
		if (type == "kmeans") {
			for (let i = 1; i < k + 1; i++)
				membership.push(i)
		} 
		state.data.membership = membership;
	},
	Kmeans:function(data, k) {
		Kmeans.Init(k,data)
		return Kmeans.cluster();
	},
	Kmeansincerter:function(data, k,centers) {
		Kmeans.Init(k,data)
	    Kmeans.setcenters(centers)
		return Kmeans.cluster();
	}
}

function updateFeaturesWithClusters(data) {
	var features = state.map.geojson.features;
	for (var i = 0; i < data.length; i++) {
		for (var j = 0; j < data[i].length; j++) {
			features[data[i][j]].properties.KMeansCluster = i;
			features[data[i][j]].properties.FeatureIndex = data[i][j];
		};
	}
}
{//other cluster
	// const math = require("../lib/math.min.js");
	// let proximity = [];
	// for (let i = 0; i < vectors.length; i++) {
	// 	let temp = [];
	// 	for (let j = 0; j < i; j++) {
	// 		temp.push(cacdistance(vectors[i], vectors[j]))
	// 	}
	// 	proximity.push(temp)
	// }
	// console.log(proximity)
	// case "single":
	// 	hac = new HierarchicalClustering(new SingleLinkage(proximity));
	// 	break;
	// case "complete":
	// 	hac = new HierarchicalClustering(new CompleteLinkage(proximity));
	// 	break;
	// case "ward":
	// 	hac = new HierarchicalClustering(new WardLinkage(proximity));
	// 	break;
	// default:
	// 	throw new IllegalStateException("Unsupported Linkage");
	
	// else {
	// 	membership = hac.partition(k);
	// }

	
	// function cacdistance(V1, V2) {
	// 	let result = 0;
	// 	for (let i = 0; i < V1.length; i++) {
	// 		result += (V1[i] - V2[i]) * (V1[i] - V2[i])
	// 	}
	// 	result = Math.sqrt(result)
	// 	return result
	// }
}
module.exports = ClusterAl;