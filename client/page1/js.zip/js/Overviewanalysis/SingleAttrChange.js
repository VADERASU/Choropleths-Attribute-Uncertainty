var state = require("../state.js");
var MapManager = require("../MapManager.js");

var SP = require("../ScatterPlot.js");
const SAC={
  data:[],
  container:d3.select("#errorlist"),
  ReRenderingList:function(){
      console.log(SAC.data)
      SAC.data.sort(Compare_ab);
      // console.log("Compare result : ",SAC.data)
      SAC.RanderingList()
      MapManager.drawRegionsMax();
    },
  RanderingList: function(){
          let maxset = findmax()
          let errorlist = SAC.container.select("svg")
              .attr("height",`${33*SAC.data.length}px`)

          let EachRegion = errorlist.selectAll("g")
                      .data(SAC.data)

              EachRegion.exit().remove()

          let thiselement = EachRegion.enter().append("g")
              thiselement.append("rect")
                      .attr("class","brect")
                      .attr("x",0)
                      .attr("y",0)
                      .attr("width","100%")
                      .attr("height",33)

          let updateelement = thiselement.merge(EachRegion)
                            .on("mouseover",function(d){
                              MapManager.highlightregion(d.id)})
                            .on("mouseout",function(d){
                              MapManager.unhighlightregion(d.id)})
                            .attr(`transform`, (d,i)=>{
                              return `translate(0 ${33*i})`});

            addtext(thiselement, "regionname","0",23)
              updateelement.select(".regionname").text(d=>{ return `Region ${d.name}`})


            addtext(thiselement, "maxval","12%",23)
            updateelement.select(".maxval").text(d=>`${d.data[0]}`)

            addrect(thiselement, "linechartrect maxrect","14%",11)
            updateelement.select(".maxrect").attr("width",d=>`${20/Math.max(maxset.plus,maxset.minus)*d.data[0]}%`)
                        .on("mouseover",function(d,i){
                          MapManager.drawRegionschange(i,d.ChangePClass,d.reflect[0])
                          // SP.ScatterPlot(d.plustsne, d.Kmeans[0]);
                        })
                        .on("mouseout",function(){
                          MapManager.drawRegionsMax();
                        })
              

            addtext(thiselement, "maxvisval","35%",23)
            updateelement.select(".maxvisval").text(d=>`${d.visualChangeP.toFixed(2)}`)

            addrect(thiselement, "linechartrect maxvisrect","40%",11)
            updateelement.select(".maxvisrect").attr("width",d=>`${20/Math.max(maxset.plus,maxset.minus)*d.visualChangeP}%`)
                        .on("mouseover",function(d,i){
                          MapManager.drawRegionschange(i,d.ChangePClass,d.reflect[0])
                        })
                        .on("mouseout",function(){
                          MapManager.drawRegionsMax();
                        })
              

            addtext(thiselement, "minval","61%",23)
            updateelement.select(".minval").text(d=>`${d.data[1]}`)

              addrect(thiselement, "linechartrect minrect","65%",11)
            updateelement.select(".minrect").attr("width",d=>`${20/Math.max(maxset.plus,maxset.minus)*d.data[1]}%`)
                        .on("mouseover",function(d,i){
                          MapManager.drawRegionschange(i,d.ChangeMClass,d.reflect[1])
                          // SP.ScatterPlot(d.minustsne, d.Kmeans[1]);
                        })
                        .on("mouseout",function(){
                          MapManager.drawRegionsMax();
                        })

              addtext(thiselement, "minvisval","80%",23)
              updateelement.select(".minvisval").text(d=>`${d.visualChangeM.toFixed(2)}`)

              addrect(thiselement, "linechartrect minvisrect","80%",11)
              updateelement.select(".minvisrect").attr("width",d=>`${20/Math.max(maxset.plus,maxset.minus)*d.visualChangeM}%`)
                        .on("mouseover",function(d,i){
                          MapManager.drawRegionschange(i,d.ChangePClass,d.reflect[0])
                        })
                        .on("mouseout",function(){
                          MapManager.drawRegionsMax();
                        })
    }
}

function addtext(container, classa,x,y){
    container.append("text").attr("class",classa)
                      .attr("x",x)
                      .attr("y",y)
}
function addrect(container, classa,x,y){
  container.append("rect").attr("class",classa)
                        .attr("x",x)
                        .attr("y",y)
                        .attr("height",15)
                        .attr("rx",5)
                        .attr("ry",5)
}


function Compare_ab(a,b){
  let avalue = a.data.reduce(( acc, cur ) => acc.changeval + cur.changeval,0),
  bvalue = b.data.reduce(( acc, cur ) => acc.changeval + cur.changeval,0)
  return bvalue - avalue;
}

function findmax(){
  let plus=SAC.data[0].data[0],
      minus=SAC.data[0].data[1]

  for (let i=1;i<SAC.data.length;i++){
      plus=Math.max(plus, SAC.data[i].data[0]);
      minus=Math.max(minus, SAC.data[i].data[1]);
  }
  return {plus:plus, minus:minus}
}


module.exports = SAC;