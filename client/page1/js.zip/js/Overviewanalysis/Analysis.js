const state = require("../state.js");
const CC = require("../compare.js");
const PC = require("../PanelControl.js");
const DM = require("../DataManager.js");
const SAC = require("./SingleAttrChange.js");

const OverviewAnalysis={

	RunErrorAnalysis : function(range , attribute){
		//show view
	  PC.OverviewAnalysis()
	  var AttrId=state.selectedFeatures.indexOf($("#AttrInput").val())
	  SAC.data=[]
	  for(let VectorsID=0; VectorsID <state.data.vectors.length; VectorsID++){
	  		let thisregionresult={id: VectorsID, data:[]}
	    	let tempvectors = $.extend(true, [], state.data.vectors)
	  		for (let thischange = range.min;thischange<=range.max;thischange++){

	  			tempvectors[VectorsID][AttrId] = tempvectors[VectorsID][AttrId]*1 + thischange*1;
		    	if(tempvectors[VectorsID][AttrId]<0)
		      		tempvectors[VectorsID][AttrId]=0;
	  			if($("#norm-input").val()==1)
		     		 tempvectors = DM.normalize(tempvectors)

		    	let change = CC.ErrorAnalysis(tempvectors)
		    	thisregionresult.data.push({
	    		    changeval		: change.changeval,
	    		    reflect			: change.reflect,
	      		    kmeans			: change.kmeans,
	      		    clusterdata		: change.clusterdata,
	      		    visualChange	: change.visualChange,
	      		    change   		: thischange
		    	})

		    	tempvectors[VectorsID][AttrId] = tempvectors[VectorsID][AttrId]*1 - thischange*1
	  		}
	   		SAC.data.push(thisregionresult)
	  }
	  SAC.ReRenderingList()
	}
}

module.exports = OverviewAnalysis