//data manager
var state = require("./state.js");
var ClusterAl = require("./ClusterAl.js");
var CrimeList = require("./CrimeList.js");
var RS = require("./RegionStatistic.js");
var DAB = require("./DrawAttrBar.js");
//Map Manager
const MapManager={
	PopupAttr : {} ,
	bounds : L.latLngBounds(L.latLng(90,180), L.latLng(-60,-180)),



	unhighlightregion:function (id){
	  state.map.layer.getLayers()[id].setStyle({color: 'white',weight:1 , fillOpacity: 0.45});
	},
	highlightregion:function (id){
	   state.map.layer.getLayers()[id].bringToFront().setStyle({color: 'red',weight:3 , fillOpacity: 1});
	},

	clearComparisonMaps:function(){
			if(state.layers.ogMap)
				state.map.obj.removeLayer(state.layers.ogMap);
			if(state.layers.maxMap)
				state.maxMap.removeLayer(state.layers.maxMap);
		},

		//draw Ori Map according to feature.properties.KMeansCluster
	drawRegions:function(){
			if(state.map.layer)
				state.map.obj.removeLayer(state.map.layer);
				state.map.layer = L.geoJson(state.map.geojson, 
				{
				  style: function(feature) {
					    return {
					        fillColor: state.color(feature.properties.KMeansCluster),
					        weight: 1,
					        opacity: 1,
					        color: 'white',
					        fillOpacity: 0.45
					    };
					}, 
				  onEachFeature: onEachFeature
				}
			).addTo(state.map.obj);
		},
	drawRegionschange:function(count,ChangeClass,reflect){
			if(state.layers.maxMap)
				state.maxMap.removeLayer(state.layers.maxMap);

			state.layers.maxMap = L.geoJson(state.map.geojson, 
				{
				  style: function (feature) {
					    return {
					        fillColor: state.color(reflect[ChangeClass[feature.properties.FeatureIndex]]),
					        weight: 1,
					        opacity: 1,
					        color: 'white',
					        fillOpacity: 0.45
					    };
					}, 
				   onEachFeature: onEachFeature
				}
			).addTo(state.maxMap);
		},
		//draw Changed Map according to Ori
	drawRegionsMax:function(){
			if(state.layers.maxMap)
				state.maxMap.removeLayer(state.layers.maxMap);

			state.layers.maxMap = L.geoJson(state.map.geojson, 
				{
				  style: function(feature) {
						// var cluster = state.maxClassConfiguration[feature.properties.FeatureIndex] === undefined ? feature.properties.KMeansCluster : state.maxClassConfiguration[feature.properties.FeatureIndex],
						 return {
					        fillColor: state.color(feature.properties.KMeansCluster),
					        weight: 1,
					        opacity: 1,
					        color: 'white',
					        fillOpacity: 0.45
					    };
					}, 
				   onEachFeature: onEachFeature
				}
			).addTo(state.maxMap);
		},
	Init : function(state){
	    state.map.obj = AddMapToDiv('og-map') 

		state.maxMap = AddMapToDiv('max-map')

		SetMapCor(state.map.obj,state.maxMap)
	}
}

function AddMapToDiv(DivId){
	let map = L.map(DivId ,{
				center: [41.854501, -87.715496],
			    minZoom: 2,
			    zoom: 11
			});
	L.tileLayer(
				"https://c.tile.openstreetmap.org/{z}/{x}/{y}.png", {
			    attribution: '&copy; ' + '<a href="https://openstreetmap.org">OpenStreetMap</a>' + ' Contributors',
			      maxZoom: 20,
			      minZoom: 1,
			      tileSize: 256,
			      noWrap: true,
			      bounds:MapManager.bounds
			}).addTo(map);
	return map
}

function SetMapCor(Map1,Map2){
	Map1.on('drag', function(e){
				let center = Map1.getCenter();
					Map2.panTo(center);});
	Map1.on('zoomend', function(e){
				let zoom = Map1.getZoom();
					Map2.setZoom(zoom);});
	Map2.on('drag', function(e){
				let center = Map2.getCenter();
					Map1.panTo(center);});
	Map2.on('zoomend', function(e){
				let zoom = Map2.getZoom();
					Map1.setZoom(zoom);});
}

var PC = require("./PanelControl.js");
var CA = require("./CombinationAnalysis.js");
//Map interaction
function onEachFeature(feature, layer) {
	// layer.bindPopup('something')
    layer.on({
    	click:function(e){
    		CA.changelist.forEach((o,id)=>{
    			if(o.size==0)
		              CA.changelist.delete(id)
    		})
			PC.SpecificationAnalysis();
   			let ID = e.target.feature.properties.FeatureIndex
   			MapManager.PopupAttr = e.target.feature.properties
   			if(!CA.changelist.has(ID))
   				CA.changelist.set(ID,new Map())

   			CA.ReRenderingList()
   			CrimeList.Rendering(MapManager.PopupAttr.crimelist)
			RS.Rendering(MapManager.PopupAttr.crimelist)
			$('#specifylist').animate({  
		        scrollTop: $(`#regionspecify${ID}`).offset().top-$('#specifylistsvg').offset().top
		    },500);
    	},
        mouseover: highlightFeature,
        mouseout: unhighlightFeature
    });
}




function highlightFeature(e) {

	let ID = e.target.feature.properties.FeatureIndex
	if(CA.changelist.has(ID)){
	 $('#specifylist').animate({  
	        scrollTop: $(`#regionspecify${ID}`).offset().top-$('#specifylistsvg').offset().top
	    },500);
	 }
    highlightPoint(e.target.feature.properties.FeatureIndex);
}
function unhighlightFeature(e) {
    var layer = e.target;
    var props = layer.feature.properties;
    
    // console.log(props);
    if(state.silhouettes){
//    	console.log(props.FeatureIndex + ': ', state.silhouettes[props.FeatureIndex]);
    	if(state.selectedList && state.selectedList.indexOf(props.FeatureIndex) > -1){
    		
    	}
    }
    unhighlightPoint(props.FeatureIndex);
}
function highlightPoint(num){
	var point = d3.select('#point' + num);
	if(point.attr("class") == "dot"){
		d3.select('#points').append("circle")
		.attr("class", "highlighted")
		.attr("cx", point.attr('cx'))
		.attr("cy", point.attr('cy'))
		.attr("r", point.attr('r'))
		.style("fill", '#a50f15')
		.attr("id", 'highlighted-point');
	}
	else{
		d3.select('#points').append("rect")
		.attr("class", "highlighted")
		.attr("x", point.attr('x'))
		.attr("y", point.attr('y'))
		.attr("width", point.attr('width'))
		.attr("height", point.attr('height'))
		.style("fill", '#a50f15')
		.attr("id", 'highlighted-point');
	}	
}
function unhighlightPoint(){
	d3.select('#highlighted-point').remove();
}

			
module.exports = MapManager;