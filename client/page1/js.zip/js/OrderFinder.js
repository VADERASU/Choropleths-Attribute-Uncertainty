var state = require("./state.js");

var OF={
	findSelectOrder: function (text){
	  let order = null
	  switch(text){
	      case "battery":
	        order = FindOrder("battery",state.selectedFeatures)
	        break;
	      case "burglary":
	        order = FindOrder("burglary",state.selectedFeatures)
	        break;
	      case "disturbances":
	        order = FindOrder("disturbances",state.selectedFeatures)
	        break;
	      case "domestic":
	        order = FindOrder("domestic_disturbances",state.selectedFeatures)
	        break;
	      case "drunkness":
	        order = FindOrder("drunkness",state.selectedFeatures)
	        break;
	      case "noise":
	        order = FindOrder("noise",state.selectedFeatures)
	        break;
	      case "robbery":
	        order = FindOrder("robbery",state.selectedFeatures)
	        break;
	      case "theft":
	        order = FindOrder("theft",state.selectedFeatures)
	        break;
	    } 
	  return order
	}
}

function FindOrder(object,set){
	  var ThisAttrID=null

	  for(let i=0;i<state.selectedFeatures.length;i++){
	    if(state.selectedFeatures[i]==object)
	      ThisAttrID=i;
	  }
	  return ThisAttrID
}


module.exports = OF