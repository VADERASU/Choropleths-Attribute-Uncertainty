const math = require("./Math/mathmatic.js");

const DM={
	normalize:function(data) {
		let result = []
		let maxmin = math.FindSetBoundary(data)
		for( let i=0; i<data.length;i++){
			result.push([])
			for (let m=0;m<data[i].length;m++){
				result[i].push(data[i][m]/maxmin[m].max)
			}
		}
		return result
	}
}

module.exports = DM;