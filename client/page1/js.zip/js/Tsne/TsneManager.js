const tsnejs = require("./tsne.js");
const state = require("../state.js");

const TM = {
	RuntSNE : function(vectors) {
		// create a tSNE instance
		// epsilon is learning rate (10 = default)
		// roughly how many neighbors each point influences (30 = default)
		// dimensionality of the embedding (2 = default)
		let tsne = new tsnejs.tSNE({
			epsilon: 10,
			perplexity: 30,
			dim: 2
		});
		tsne.initDataRaw(vectors);

		for (var k = 0; k < 500; k++) {
			tsne.step(); // every time you call this, solution gets better
		}
		state.data.pca = tsne.getSolution(); // Y is an array of 2-D points that you can plot
		state.tsnemachine=tsne
		console.log(state.data.pca)
		console.log("---------------tSNE complite---------------")
	},
	stepwithdata(data){
		let tsne =  $.extend(true, {}, state.tsnemachine);

		tsne.initDataDist(data)
		for (var k = 0; k < 500; k++) {
			tsne.step(); // every time you call this, solution gets better
		}
		return tsne.getSolution()
	}
}
module.exports = TM