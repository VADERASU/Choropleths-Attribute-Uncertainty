var state = require("./state.js");
var MA= require("./Math/mathmatic.js");
var CA = require("./CombinationAnalysis.js");


const CrimeList={
	container:d3.select("#CrimeList").select(".list"),
	crimemarkers:[],
	oldmarker:null,
	nowid:null,
	Rendering: function(data){
		let thislist = CrimeList.container.selectAll(".crimeevent")
						.data(data)
		
	  	CrimeList.crimemarkers.forEach(o=>{
		  state.map.obj.removeLayer(o)
	  	})
	  	CrimeList.crimemarkers =[]
	  	data.forEach((d,i)=>{
	  		console.log()
	  		if(d.nowposition!=undefined){
	  			let thismarker = L.marker(d.nowposition,{draggable:true, riseOnHover:true})
	  			thismarker.on({
	  				mouseover:function(){
		  				$('#crimelistdiv').animate({  
					        scrollTop: $(`#crimeevent${d.id}`).offset().top-$('#crimelistdiv div').offset().top
					    },50);
					    d3.selectAll(".crimeevent").classed("isselected",false)
					    d3.selectAll(`#crimeevent${d.id}`).classed("isselected",true)

					    CrimeList.oldmarker = L.marker([d.latitude,d.longitude])
					    state.map.obj.addLayer(CrimeList.oldmarker)
			    	},
			    	mouseout:function(){
			    		state.map.obj.removeLayer(CrimeList.oldmarker)
			    	}
			    })
	  			CrimeList.crimemarkers.push(thismarker)	
	  		}
	  		
	  		else{
	  			let thismarker = L.marker([d.latitude,d.longitude],{draggable:true, riseOnHover:true})
	  			thismarker.on({mouseover:function(e){
		    		$('#crimelistdiv').animate({  
				        scrollTop: $(`#crimeevent${d.id}`).offset().top-$('#crimelistdiv div').offset().top
				    },50);
				    d3.selectAll(".crimeevent").classed("isselected",false)
				    d3.selectAll(`#crimeevent${d.id}`).classed("isselected",true)
			    	}})
	  			CrimeList.crimemarkers.push(thismarker)	
	  		}

		  	CrimeList.crimemarkers[CrimeList.crimemarkers.length-1].on({
		  		dragstart:function(e){
			    		console.log(d.latitude,d.longitude)
			    	},
		    	dragend:function(e){

		    		let nowID=null;
		    		let nowposition =[d.latitude,d.longitude]
		    		if(d.nowposition!=undefined){
						nowposition = d.nowposition
		    		}

		    		state.map.geojson.features.forEach((area,nowid)=>{
		    			if(MA.IsPointInArea([nowposition[1],nowposition[0]],area.geometry.bbox)){
		    				let areacoor=[]
							for (let thiscoor of area.geometry.coordinates[0]){
								areacoor.push({x:thiscoor[0],y:thiscoor[1]})
							}
							if(MA.checkPP({x:nowposition[1],y:nowposition[0]}, areacoor)){
								nowID=nowid
							}
						}})


		    		state.map.geojson.features.forEach((area,newid)=>{
		    			if(MA.IsPointInArea([e.target._latlng.lng,e.target._latlng.lat],area.geometry.bbox)){
		    				let areacoor=[]
							for (let thiscoor of area.geometry.coordinates[0]){
								areacoor.push({x:thiscoor[0],y:thiscoor[1]})
							}
							if(MA.checkPP({x:e.target._latlng.lng,y:e.target._latlng.lat}, areacoor)){
								console.log(i,"find",nowID)
				    			switch(d.category){
									case "BURGLARY":
										CA.specify(nowID,"burglary",CA.returnObjAttr("burglary",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"burglary",CA.returnObjAttr("burglary",CA.features[newid].properties)*1+1)
										break;
									case "DISTURBANCES":
										CA.specify(nowID,"disturbances",CA.returnObjAttr("disturbances",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"disturbances",CA.returnObjAttr("disturbances",CA.features[newid].properties)*1+1)
										break;
									case "\"DOMESTIC DISTURBANCE\"":
										CA.specify(nowID,"domestic",CA.returnObjAttr("domestic",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"domestic",CA.returnObjAttr("domestic",CA.features[newid].properties)*1+1)
										break;
									case "DRUNKNESS":
										CA.specify(nowID,"drunkness",CA.returnObjAttr("drunkness",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"drunkness",CA.returnObjAttr("drunkness",CA.features[newid].properties)*1+1)
										break;
									case "NOISE":
										CA.specify(nowID,"noise",CA.returnObjAttr("noise",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"noise",CA.returnObjAttr("noise",CA.features[newid].properties)*1+1)
										break;
									case "ROBBERY":
										CA.specify(nowID,"robbery",CA.returnObjAttr("robbery",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"robbery",CA.returnObjAttr("robbery",CA.features[newid].properties)*1+1)
										break;
									case "BATTERY":
										CA.specify(nowID,"battery",CA.returnObjAttr("battery",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"battery",CA.returnObjAttr("battery",CA.features[newid].properties)*1+1)
										break;
									case "THEFT":
										CA.specify(nowID,"theft",CA.returnObjAttr("theft",CA.features[nowID].properties)*1-1)
										CA.specify(newid,"theft",CA.returnObjAttr("theft",CA.features[newid].properties)*1+1)
										break;
								}
							var CC = require("./compare.js");
							CC.RunCombineAnalysis($('#kMeans-input').val()*1)
							}
		    			}
		    		})


		    			d.nowposition=[e.target._latlng.lat,e.target._latlng.lng]
			    		CrimeList.crimemarkers[i].on({
				  				mouseover:function(){
					  				$('#crimelistdiv').animate({  
								        scrollTop: $(`#crimeevent${d.id}`).offset().top-$('#crimelistdiv div').offset().top
								    },50);
								    d3.selectAll(".crimeevent").classed("isselected",false)
								    d3.selectAll(`#crimeevent${d.id}`).classed("isselected",true)

								    CrimeList.oldmarker = L.marker([d.latitude,d.longitude])
								    state.map.obj.addLayer(CrimeList.oldmarker)
						    	},
						    	mouseout:function(){
						    		state.map.obj.removeLayer(CrimeList.oldmarker)
						    	}
						    })
			    	}
			    });
		  	state.map.obj.addLayer(CrimeList.crimemarkers[CrimeList.crimemarkers.length-1])
	  	})


		let thisevent = thislist.enter().append("div")
		  .attr("class", "crimeevent")

		updateevent = thisevent.merge(thislist)
		  .attr("id", (d, i)=> `crimeevent${d.id}`)
		  .on("mouseover",function(d, i){
		  	// console.log(d.id,i)
		  })
		thisevent.append("div").classed("eventid",true)
		updateevent.select(".eventid").text(function(d){return d.id})

		thisevent.append("div").classed("eventcategory",true)
		updateevent.select(".eventcategory").text(function(d){
			if(d.category=="\"DOMESTIC DISTURBANCE\"")
				return "DOMESTIC"
			return d.category
		})

		thisevent.append("div").classed("eventdate",true)
		updateevent.select(".eventdate").text(function(d){return d.incident_date})

		thislist.exit().remove()
	}
}





module.exports= CrimeList