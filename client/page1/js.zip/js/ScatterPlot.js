
var state = require("./state.js");
const SP={}
SP.ScatterPlot=function (data,kmeans){
	var margin = {top: 20, right: 20, bottom: 20, left: 30},
    padding = {top: 20,  right: 20,  bottom: 10,  left: 10},
    width = $('#scat').width() - margin.left - margin.right - padding.left - padding.right,
    height = $('#scat').height() - margin.top - margin.bottom - padding.top - padding.bottom;

	/* 
	 * value accessor - returns the value to encode for a given data object.
	 * scale - maps value to a visual display encoding, such as a pixel position.
	 * map function - maps from data value to display value
	 * axis - sets up axis
	 */ 

	// setup x 
	var xValue = function(d) { return d[0];}, // data -> value
		xScale = d3.scaleLinear().range([0, width]),
	    xMap = function(d) { return xScale(xValue(d));} // data -> display
	    // xAxis = ;

	// setup y
	var yValue = function(d) { return d[1];}, // data -> value
		yScale = d3.scaleLinear().range([height, 0]),
	    yMap = function(d) { return yScale(yValue(d));} // data -> display
	    // yAxis = d3.axisBottom(yScale);

	// setup fill color
	var cValue = function(d, i) {
			for(var ki = 0; ki < kmeans.length; ki++){
				for(var kj = 0; kj < kmeans[ki].length; kj++){
					if(kmeans[ki][kj] == i)
						return ki;
				}
			}
	};

	$('#scat-svg').remove();

	// add the graph canvas to the body of the webpage
	var svg = d3.select('#scat').append("svg")
		.attr("id", "scat-svg")
	    .attr("width", width + margin.left + margin.right)
	    .attr("height", height + margin.top + margin.bottom)
	  .append("g")
	    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	// don't want dots overlapping axis, so add in buffer to data domain
	xScale.domain([d3.min(data, xValue) * 1.05, d3.max(data, xValue) * 1.05]);
	yScale.domain([d3.min(data, yValue) * 1.05, d3.max(data, yValue) * 1.05]);

	// x-axis
	svg.append("g")
	  // .attr("class", "x axis")
	  .attr("transform", "translate(0," + height + ")")
	  .call(d3.axisBottom(xScale));
	// .append("text")
	//   .attr("class", "label")
	//   .attr("x", width)
	//   .attr("y", -6)
	//   .style("text-anchor", "end")
	//   .text("X");

	// y-axis
	svg.append("g")
	  .attr("class", "y axis")
	  .call(d3.axisLeft(yScale))
	// .append("text")
	//   .attr("class", "label")
	//   .attr("transform", "rotate(-90)")
	//   .attr("y", 6)
	//   .attr("dy", ".71em")
	//   .style("text-anchor", "end")
	//   .text("Y");

	svg.append("g").selectAll("text").data([["sil"], ["id"]]).enter().append("text")
	.attr("id", function(d, i) { return "scatterTooltip_" + (i? "id" : "sil");})
	.attr("x", width - ("Silhouette: D.DDDD".length))
	.attr("y", function (d, i) {return i==0? -10: 0;})
	.style("text-anchor", "end")
	.text("")


	var hulls = svg.append("g")
	l:for(var i = 0; i < kmeans.length; i++){
		var hull = hulls.append("path")
    	.attr("class", "hull")
    	.attr("fill", state.color(i))
    	.attr("stroke", state.color(i))
    	.attr("id", function(d, i){ return "k" + i;});

    	var filteredData = new Array(kmeans[i].length);
    	for(var j = 0; j < filteredData.length; j++){
    		var index = kmeans[i][j];
    		filteredData[j] = [xMap(data[index]), yMap(data[index])];
    	}
    	if(filteredData.length<2)
    		continue l;
    	hull.datum(d3.polygonHull(filteredData)).attr("d", function(d) { 
    		if (d.length === 0) return ""; return "M" + d.join("L") + "Z"; 
    	});
	}

	var dots = svg.append("g")
		.attr("id", "points");
	
	// draw dots
	dots.selectAll(".dot")
	  .data(data)
	  .enter().append("circle")
	  .attr("class", "dot")
	  .attr("r", 3.5)
	  .attr("cx", xMap)
	  .attr("cy", yMap)
	  .attr("id", function(d, i){ return "point" + i;})
	  .style("fill", function(d, i) { return state.color(cValue(d, i));}) 
	  .on("mouseover", function(d, i) {
	  })
	  .on("mouseout", function(d, i) {
	  });
}

function convertPoint(num, type){
	var point = d3.select('#point' + num);
	
	if(point.attr("class") == "dot" && type == "square"){
		var r = parseFloat(point.attr('r'));
		var width = r * 2,
			x = parseFloat(point.attr('cx')) - r,
			y = parseFloat(point.attr('cy')) - r,
			fill = point.style('fill');
		point.remove();
		
		d3.select('#points').append("rect")
			.attr("class", "square")
			.attr("x", x)
			.attr("y", y)
			.attr("width", width)
			.attr("height", width)
			.style("fill", fill)
			.attr("id", 'point' + num);
	}
	else if(point.attr("class") == "square" && type == "dot"){
		var r = point.attr('width') / 2;
		var cx = parseFloat(point.attr('x')) + r,
			cy = parseFloat(point.attr('y')) + r,
			fill = point.style('fill');
//		console.log(r, cx, cy);
		point.remove();
		
		d3.select('#points').append("circle")
			.attr("class", "dot")
			.attr("cx", cx)
			.attr("cy", cy)
			.attr("r", r)
			.style("fill", fill)
			.attr("id", 'point' + num);
	}
	else{
		console.log('Do nothing. class: ' + point.attr("class") + ', type: ' + type);
	}
}

function convertAllSelected(type){
	if(state.selectedList){
		for (var i = 0; i < state.selectedList.length; i++) {
			convertPoint(state.selectedList[i], type);
		};
	}
}

function highlightPoint(num){
	var point = d3.select('#point' + num);
	if(point.attr("class") == "dot"){
		d3.select('#points').append("circle")
		.attr("class", "highlighted")
		.attr("cx", point.attr('cx'))
		.attr("cy", point.attr('cy'))
		.attr("r", point.attr('r'))
		.style("fill", '#a50f15')
		.attr("id", 'highlighted-point');
	}
	else{
		d3.select('#points').append("rect")
		.attr("class", "highlighted")
		.attr("x", point.attr('x'))
		.attr("y", point.attr('y'))
		.attr("width", point.attr('width'))
		.attr("height", point.attr('height'))
		.style("fill", '#a50f15')
		.attr("id", 'highlighted-point');
	}	
}

function unhighlightPoint(){
	d3.select('#highlighted-point').remove();
}

module.exports = SP