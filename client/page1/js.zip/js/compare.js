var ClusterAl = require("./ClusterAl.js");
//data manager
var state = require("./state.js");
var MapManager = require("./MapManager.js");
var CA = require("./CombinationAnalysis.js");

var PC = require("./PanelControl.js");
var DM = require("./DataManager.js");

var CC={
      compare:function(Old, New) {
              const record = new Map();
              // record every ele's pre group Id
              for (let i = 0; i < Old.length; ++ i) {
                for (let j = 0; j < Old[i].length; ++ j) {
                  record.set(Old[i][j], i);
                }
              }
              const proportionInNewGroup = [];
              for (let i = 0; i < Old.length; ++ i) {
                proportionInNewGroup.push([]);
                for (let j = 0; j < Old.length; ++ j)
                  proportionInNewGroup[i].push(0);
              }
              for (let i = 0; i < New.length; ++ i) {
                for (let j = 0; j < New[i].length; ++ j) {
                  const preGroup = record.get(New[i][j]);
                  proportionInNewGroup[preGroup][i] ++;
                }
              }
              const vis = new Map(),
                  reflect = [];
              let sum = 0;
              for (let i = 0; i < proportionInNewGroup.length; ++ i) {
                let maxV = -1, maxP = -1;
                for (let j = 0; j < proportionInNewGroup[i].length; ++ j) {
                  if (vis.has(j)) continue;
                  if (maxV < proportionInNewGroup[i][j]) {
                    maxV = proportionInNewGroup[i][j];
                    maxP = j;
                  } else if (maxV == proportionInNewGroup[i][j]) {
                    let p0 = maxV / New[j].length,
                        p1 = maxV / New[maxP].length;
                    if (p0 - p1 > 0) {
                      maxV = proportionInNewGroup[i][j];
                      maxP = j;
                    }
                  }
                }
                reflect[i] = maxP;
                sum += Old[i].length - maxV;
                vis.set(maxP, true);
              }
              // console.log(reflect);
              return {sum:sum, reflect:reflect};
            }
}

var TsneM = require("./Tsne/TsneManager.js");


CC.RunErrorAnalysis=function(min,max,k){
  PC.OverviewAnalysis()
  var AttrId=state.selectedFeatures.indexOf($("#AttrInput").val())
  SAC.data=[]
  for(let VectorsID=0;VectorsID <state.data.vectors.length;VectorsID++){
    let tempvectors = $.extend(true, [], state.data.vectors)
    tempvectors[VectorsID][AttrId] = tempvectors[VectorsID][AttrId]*1+max*1;
    if($("#norm-input").val()==1){
      tempvectors = DM.normalize(tempvectors)
    }
    let pluschange = CC.ErrorAnalysis(tempvectors, k)
    // let plustsne = TsneM.stepwithdata(tempvectors);

    tempvectors = $.extend(true, [], state.data.vectors)
    tempvectors[VectorsID][AttrId]=tempvectors[VectorsID][AttrId]*1+min*1;
    if(tempvectors[VectorsID][AttrId]<0)
      tempvectors[VectorsID][AttrId]=0;
    if($("#norm-input").val()==1){
      tempvectors = DM.normalize(tempvectors)
    }
    let minuschange = CC.ErrorAnalysis(tempvectors, k)
    // let minustsne = TsneM.stepwithdata(tempvectors);

    let element = {
      name:VectorsID, 
      id: VectorsID, 
      data:[pluschange.changeval, minuschange.changeval],
      reflect:[pluschange.reflect, minuschange.reflect],
      // plustsne:plustsne,
      // minustsne:minustsne,
      Kmeans:[pluschange.kmeans,minuschange.kmeans],
      ChangePClass:pluschange.clusterdata,
      ChangeMClass:minuschange.clusterdata,
      visualChangeP:pluschange.visualChange,
      visualChangeM:minuschange.visualChange,
    }
   SAC.data.push(element)
  }
  SAC.ReRenderingList()
}

CC.RunCombineAnalysis = function (k){
  PC.SpecificationAnalysis()
  let tempvectors = $.extend(true, [], CA.data)
  if($("#norm-input").val()==1){
      tempvectors = DM.normalize(tempvectors)
  }
  CA.changedata = CC.ErrorAnalysis(tempvectors, k)

  CA.ReRenderingList()
}

CC.ErrorAnalysis=function(cluster){
  let result = {}
  let tempC  = ClusterAl.Kmeansincerter(cluster, state.data.kMeansK , state.data.stacenters)
  let change = CC.compare(state.data.kmeans, tempC.clustersnormal)

  result.changeval = change.sum
  result.reflect = change.reflect
  result.kmeans =  tempC.clustersnormal
  result.clusterdata = CC.featurelist( tempC.clustersnormal)
  result.Changelist = FindChangeRegion(result.clusterdata, result.reflect);
  result.visualChange = 0;
  result.Changelist.forEach( (ob)=>{
      result.visualChange += CacVisualChange(result.clusterdata,ob)
  })
  return result
}



function CacVisualChange(Cluster,id){
  let Adjlist=[]
  state.data.PolygonAdjList[id].forEach((o,i)=>{
    if (o&&id!=i){
      Adjlist.push(i)
    }
  })
  //ori
  let orival=0
  //new
  let newval=0

  for( let adjid of Adjlist){
    if(state.map.geojson.features[adjid].KMeansCluster != state.map.geojson.features[id].KMeansCluster){
      orival+= (1/Adjlist.length)
    }
    if(Cluster[adjid] != Cluster[id]){
      newval+= (1/Adjlist.length)
    }
  }
  //bijiao
  return Math.abs(newval-orival)
}

function FindChangeRegion(Cluster, reflect){
  let result = [];
  let OldC = state.map.geojson.features
  Cluster.forEach( (ob,i)=>{
    if(reflect[ob] != OldC[i].properties.KMeansCluster){
      result.push(i)
    }
  })
  return result
}

CC.featurelist = function(data){
  var result= new Array(state.data.vectors.length)

  for(var i = 0; i < data.length; i++){
    for (var j = 0; j < data[i].length; j++) {
      result[data[i][j]]= i;
    };
  }
  return result
}


// let A = [[1,2,3],[4],[6,7],[8,9,5]]
// let B = [[4,6,7],[1,2,3],[5],[8,9]]
// console.log(CC.compare(A, B))

module.exports = CC
