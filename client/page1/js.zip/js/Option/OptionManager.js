
const OM = {
	init:function(){

	}
}
module.exports = OM