var state = require("../state.js");
var Analysis = require("../Overviewanalysis/Analysis.js");
var LineC = require("../LineChart.js");

const OO = {
	SetAttrInput : function (){
		$('#AttrInput').selectpicker('destroy');
		let attrinput = d3.select("#AttrInput")
		attrinput.selectAll("option").remove()
		attrinput.append("option")
				.attr("value",state.selectedFeatures[0])
				.attr("selected",true)
				.text(state.selectedFeatures[0])
		for(let i=1;i<state.selectedFeatures.length;i++){
			attrinput.append("option")
				.attr("value",state.selectedFeatures[i])
				.text(state.selectedFeatures[i])
		}
		$('#AttrInput').selectpicker('show');
		$('#AttrInput').on('changed.bs.select', function (e) {
			OO.SetErroSlider()
		});
		OO.SetErroSlider()
	},
	SetErroSlider : function (){
		let distribution = LineC.datadistribution(OO.GetAttrInput(),[-10,10])

		$("#error-slider-range").slider({
      		range: true,
      		step:1,
	     	min: -5*Math.floor(distribution.step),
	      	max: 5*Math.floor(distribution.step),
		  	values: [ -Math.floor(distribution.step), Math.floor(distribution.step) ],
		      stop:function(event, ui){
		      	Analysis.RunErrorAnalysis( {min: ui.values[ 0 ] , max : ui.values[ 1 ]}
		      		, OO.GetAttrInput())
		      },
		      slide: function(event, ui) {
		        $( "#errordefine" ).val("error: "+ui.values[ 0 ] + " - " + ui.values[ 1 ] );
		      }
	    });
	    $( "#errordefine" ).val( `error: ${OO.GetMin()} ~ ${OO.GetMax()}`);
	    Analysis.RunErrorAnalysis({min: OO.GetMin() ,  max : OO.GetMax()} , OO.GetAttrInput())
	},
	GetAttrInput : function(){
		return $('#AttrInput').val()
	},
	GetMin(){
		return $( "#error-slider-range" ).slider( "values", 0 )
	},
	GetMax(){
		return $( "#error-slider-range" ).slider( "values", 1 )
	},
	GetRange(){
		return $( "#error-slider-range" ).slider( "values" )
	}

}
module.exports = OO